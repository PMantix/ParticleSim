/*pub trait Spatial {
    fn position(&self) -> ultraviolet::Vec2;
    // Add more trait methods as needed
}*/